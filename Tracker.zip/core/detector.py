import os
import time
import cv2
import numpy as np
from ultralytics import YOLO
from PyQt5.QtCore import QThread, pyqtSignal
import serial
import serial.tools.list_ports
from core.camera import CameraConfig

try:
    import torch
except Exception:
    torch = None


class DetectionThread(QThread):
    frame_ready = pyqtSignal(np.ndarray)
    angles_ready = pyqtSignal(float, float)
    error_signal = pyqtSignal(str)
    fps_ready = pyqtSignal(float)

    def __init__(self, model_path, video_source, horizontal_fov=60.0, vertical_fov=45.0,
                 serial_port=None, baud_rate=9600, device=None, imgsz=640, half=None,
                 detect_every_n_frames=1, max_reconnect_attempts=5, reconnect_delay_sec=2.0):
        super().__init__()
        self.model_path = model_path
        self.video_source = video_source
        self.camera_config = CameraConfig(horizontal_fov, vertical_fov)
        self.running = False
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.serial_connection = None

        # تنظیمات نمایش
        self.display_width = 800

        # تنظیمات کارایی (performance settings)
        # device=None -> auto-detect: از GPU (CUDA) استفاده می‌شود اگر موجود باشد، وگرنه CPU
        self.device = device
        self.imgsz = imgsz
        self.half = half  # None -> فقط روی CUDA به صورت خودکار فعال می‌شود
        self.detect_every_n_frames = max(1, int(detect_every_n_frames))

        # تنظیمات اتصال مجدد برای استریم RTSP (مثلا وقتی IP دوربین در دسترس نیست)
        self.max_reconnect_attempts = max_reconnect_attempts
        self.reconnect_delay_sec = reconnect_delay_sec

    def _resolve_device(self):
        """تعیین دستگاه اجرای مدل (CPU/GPU) بر اساس تنظیمات کاربر و سخت‌افزار موجود"""
        cuda_available = bool(torch and torch.cuda.is_available())

        if self.device in (None, "auto", "Auto"):
            return ("cuda:0" if cuda_available else "cpu"), cuda_available

        if str(self.device).lower() == "cpu":
            return "cpu", cuda_available

        # کاربر صریحا GPU را درخواست کرده است
        if not cuda_available:
            raise RuntimeError(
                "GPU (CUDA) was requested but PyTorch did not detect a CUDA-capable GPU/driver "
                "on this machine. Install a CUDA-enabled PyTorch build, or set Device to 'Auto' or 'CPU'."
            )
        return self.device, cuda_available

    def run(self):
        try:
            resolved_device, cuda_available = self._resolve_device()
            effective_half = self.half if self.half is not None else cuda_available

            print(f"[DetectionThread] Model: {self.model_path}")
            print(f"[DetectionThread] Inference device: {resolved_device} "
                  f"(half precision: {effective_half}, imgsz: {self.imgsz}, "
                  f"detect every {self.detect_every_n_frames} frame(s))")

            # بارگذاری مدل
            model = YOLO(self.model_path)

            is_rtsp = isinstance(self.video_source, str) and self.video_source.startswith('rtsp')

            # برای استریم‌های RTSP یک تایم‌اوت کوتاه برای FFmpeg تنظیم می‌شود تا اگر
            # دوربین در دسترس نباشد (مثلا بعد از تغییر IP آداپتور شبکه)، برنامه به جای
            # هنگ‌کردن طولانی‌مدت خیلی سریع خطا را گزارش کند
            if is_rtsp:
                os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|stimeout;5000000'

            # اتصال به منبع ویدئو
            cap = cv2.VideoCapture(self.video_source)

            if not cap.isOpened():
                if is_rtsp:
                    self.error_signal.emit(
                        f"Cannot open camera stream at {self.video_source}.\n\n"
                        "Check that:\n"
                        "- the camera's IP is reachable from this PC (try 'ping <camera IP>')\n"
                        "- this PC's network adapter is on the same subnet as the camera\n"
                        "- the RTSP username/password/path are correct"
                    )
                else:
                    self.error_signal.emit(f"Cannot open video source: {self.video_source}")
                return

            # اتصال به پورت سریال
            if self.serial_port:
                try:
                    self.serial_connection = serial.Serial(
                        port=self.serial_port,
                        baudrate=self.baud_rate,
                        timeout=1
                    )
                    print(f"Serial connection established on {self.serial_port}")
                except Exception as e:
                    self.error_signal.emit(f"Serial connection failed: {str(e)}")

            self.running = True

            frame_count = 0
            consecutive_failures = 0
            cached_box = None  # آخرین باکس شناسایی‌شده، برای فریم‌هایی که تشخیص روی آن‌ها اجرا نمی‌شود

            fps_smoothed = 0.0
            last_time = time.time()

            while self.running:
                ret, frame = cap.read()

                if not ret:
                    if is_rtsp:
                        # اتصال به دوربین قطع شده - تلاش محدود برای اتصال مجدد به جای
                        # حلقه بی‌نهایت و بی‌صدا که چیزی روی صفحه نشان نمی‌دهد
                        consecutive_failures += 1
                        if consecutive_failures > self.max_reconnect_attempts:
                            self.error_signal.emit(
                                f"Lost connection to the camera at {self.video_source} after "
                                f"{self.max_reconnect_attempts} reconnect attempts.\n\n"
                                "This usually means the PC can no longer reach the camera's IP "
                                "address (for example, after changing the network adapter's IP or "
                                "subnet). Verify the camera and PC are on the same subnet and that "
                                "the camera is reachable, then try again."
                            )
                            break
                        cap.release()
                        self.msleep(int(self.reconnect_delay_sec * 1000))
                        cap = cv2.VideoCapture(self.video_source)
                        continue
                    else:
                        # پایان فایل ویدئویی
                        break

                consecutive_failures = 0

                # تشخیص اشیاء - فقط هر N فریم یک‌بار اجرا می‌شود (قابل تنظیم)
                # تا سرعت نمایش از سرعت تشخیص جدا شود
                run_detection = (frame_count % self.detect_every_n_frames == 0)
                frame_count += 1

                if run_detection:
                    results = model(frame, device=resolved_device, half=effective_half,
                                     imgsz=self.imgsz, verbose=False)
                    cached_box = self._extract_best_box(results, model)

                if cached_box is not None:
                    self._draw_and_emit(frame, cached_box)

                # رسم خط‌های مرکز
                h, w = frame.shape[:2]
                cv2.line(frame, (w // 2, 0), (w // 2, h), (0, 255, 255), 1)
                cv2.line(frame, (0, h // 2), (w, h // 2), (0, 255, 255), 1)

                # محاسبه و نمایش FPS واقعی پردازش (برای عیب‌یابی سرعت)
                now = time.time()
                dt = now - last_time
                last_time = now
                if dt > 0:
                    instant_fps = 1.0 / dt
                    fps_smoothed = instant_fps if fps_smoothed == 0 else (0.9 * fps_smoothed + 0.1 * instant_fps)
                cv2.putText(frame, f"FPS: {fps_smoothed:.1f}", (10, h - 15),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                if frame_count % 10 == 0:
                    self.fps_ready.emit(fps_smoothed)

                # ریسایز فریم برای نمایش
                display_frame = self._resize_for_display(frame, self.display_width)

                # ارسال فریم برای نمایش
                self.frame_ready.emit(display_frame)

            cap.release()
            if self.serial_connection and self.serial_connection.is_open:
                self.serial_connection.close()

        except Exception as e:
            self.error_signal.emit(f"Detection error: {str(e)}")

    def _extract_best_box(self, results, model):
        """اولین باکس شناسایی‌شده را استخراج می‌کند (همان رفتار قبلی برنامه)"""
        for result in results:
            boxes = result.boxes
            if len(boxes) > 0:
                box = boxes[0]
                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                conf = float(box.conf[0].cpu().numpy())
                cls = int(box.cls[0].cpu().numpy())
                label = f"{model.names[cls]} {conf:.2f}"
                return (x1, y1, x2, y2, label)
        return None

    def _draw_and_emit(self, frame, box):
        """رسم باکس روی فریم و ارسال زوایا (از تشخیص تازه یا کش‌شده)"""
        x1, y1, x2, y2, label = box
        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2

        h, w = frame.shape[:2]
        azimuth, elevation = self.camera_config.calculate_angles(center_x, center_y, w, h)

        if self.serial_connection and self.serial_connection.is_open:
            try:
                hex_data = self.angles_to_hex(azimuth, elevation)
                self.serial_connection.write(hex_data)
            except Exception as e:
                print(f"Serial write error: {e}")

        self.angles_ready.emit(azimuth, elevation)

        cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
        cv2.putText(frame, label, (int(x1), int(y1) - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        angle_text = f"Az: {azimuth:+.2f}° El: {elevation:+.2f}°"
        cv2.putText(frame, angle_text, (int(x1), int(y2) + 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2)

        frame_center_x = w // 2
        frame_center_y = h // 2
        cv2.line(frame, (frame_center_x, frame_center_y),
                 (int(center_x), int(center_y)), (255, 0, 0), 2)
        cv2.circle(frame, (int(center_x), int(center_y)), 5, (0, 0, 255), -1)

    def _resize_for_display(self, frame, target_width):
        """ریسایز فریم برای نمایش با حفظ نسبت تصویر"""
        h, w = frame.shape[:2]
        if w > target_width:
            scale = target_width / w
            new_w = target_width
            new_h = int(h * scale)
            return cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        return frame

    def angles_to_hex(self, azimuth, elevation):
        """تبدیل زوایا به فرمت HEX"""
        header = bytes([0xAA, 0x55])

        # ضرب در 100 برای حفظ دو رقم اعشار
        azimuth_int = int(azimuth * 100)
        elevation_int = int(elevation * 100)

        azimuth_bytes = azimuth_int.to_bytes(4, byteorder='little', signed=True)
        elevation_bytes = elevation_int.to_bytes(4, byteorder='little', signed=True)

        data = header + azimuth_bytes + elevation_bytes
        checksum = 0
        for byte in data:
            checksum ^= byte

        final_data = data + bytes([checksum])

        return final_data

    def stop(self):
        self.running = False
        self.wait()


def get_available_serial_ports():
    """لیست پورت‌های سریال موجود"""
    ports = serial.tools.list_ports.comports()
    return [port.device for port in ports]
