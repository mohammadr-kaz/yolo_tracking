from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QPushButton, QLabel, QLineEdit, QFileDialog,
                             QGroupBox, QComboBox, QRadioButton, QButtonGroup,
                             QMessageBox, QSpinBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QImage, QPixmap
import cv2
import numpy as np

from core.camera import CameraConfig, CameraStreamThread
from core.detector import DetectionThread, get_available_serial_ports
from gui.radar_widget import RadarWidget
from gui.styles import DARK_MILITARY_STYLE, ACCENT, BORDER

DEFAULT_BAUD_RATE = 9600


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("YOLO Tactical Tracker")
        self.setGeometry(100, 100, 1400, 900)
        self.setStyleSheet(DARK_MILITARY_STYLE)

        self.detection_thread = None
        self.stream_thread = None
        self.camera_config = None

        self.init_ui()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)

        # پنل کنترل (سمت چپ)
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel, 1)

        # پنل نمایش (سمت راست)
        display_panel = self.create_display_panel()
        main_layout.addWidget(display_panel, 3)

    def create_control_panel(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # Model selection
        model_group = QGroupBox("Model Configuration")
        model_layout = QVBoxLayout()

        self.model_path_input = QLineEdit()
        self.model_path_input.setPlaceholderText("Path to YOLO model...")
        model_browse_btn = QPushButton("Browse Model")
        model_browse_btn.clicked.connect(self.browse_model)

        model_layout.addWidget(QLabel("Model Path:"))
        model_layout.addWidget(self.model_path_input)
        model_layout.addWidget(model_browse_btn)
        model_group.setLayout(model_layout)
        layout.addWidget(model_group)

        # Video source selection
        video_group = QGroupBox("Video Source")
        video_layout = QVBoxLayout()

        # انتخاب نوع منبع
        self.source_type_group = QButtonGroup()
        self.file_radio = QRadioButton("Video File")
        self.rtsp_radio = QRadioButton("RTSP Stream")
        self.file_radio.setChecked(True)

        self.source_type_group.addButton(self.file_radio)
        self.source_type_group.addButton(self.rtsp_radio)

        self.file_radio.toggled.connect(self.toggle_source_type)

        video_layout.addWidget(self.file_radio)
        video_layout.addWidget(self.rtsp_radio)

        # ورودی مسیر فایل
        self.video_path_input = QLineEdit()
        self.video_path_input.setPlaceholderText("Path to video file...")
        self.video_browse_btn = QPushButton("Browse Video")
        self.video_browse_btn.clicked.connect(self.browse_video)

        # ورودی RTSP - فقط IP و Port لازم است
        self.rtsp_container = QWidget()
        rtsp_container_layout = QVBoxLayout(self.rtsp_container)
        rtsp_container_layout.setContentsMargins(0, 0, 0, 0)

        rtsp_address_layout = QHBoxLayout()
        self.rtsp_ip = QLineEdit()
        self.rtsp_ip.setPlaceholderText("192.168.1.100")
        self.rtsp_port = QLineEdit()
        self.rtsp_port.setPlaceholderText("554")
        self.rtsp_port.setMaximumWidth(80)
        rtsp_address_layout.addWidget(QLabel("IP:"))
        rtsp_address_layout.addWidget(self.rtsp_ip)
        rtsp_address_layout.addWidget(QLabel("Port:"))
        rtsp_address_layout.addWidget(self.rtsp_port)

        rtsp_container_layout.addLayout(rtsp_address_layout)
        self.rtsp_container.setVisible(False)

        video_layout.addWidget(QLabel("Source:"))
        video_layout.addWidget(self.video_path_input)
        video_layout.addWidget(self.video_browse_btn)
        video_layout.addWidget(self.rtsp_container)

        video_group.setLayout(video_layout)
        layout.addWidget(video_group)

        # Performance settings
        perf_group = QGroupBox("Performance")
        perf_layout = QVBoxLayout()

        self.device_combo = QComboBox()
        self.device_combo.addItems(["Auto (recommended)", "CPU", "GPU (CUDA)"])
        perf_layout.addWidget(QLabel("Device:"))
        perf_layout.addWidget(self.device_combo)

        self.imgsz_combo = QComboBox()
        self.imgsz_combo.addItems(["320", "416", "480", "640", "960", "1280"])
        self.imgsz_combo.setCurrentText("640")
        perf_layout.addWidget(QLabel("Inference size (smaller = faster):"))
        perf_layout.addWidget(self.imgsz_combo)

        self.detect_n_spin = QSpinBox()
        self.detect_n_spin.setRange(1, 10)
        self.detect_n_spin.setValue(1)
        perf_layout.addWidget(QLabel("Detect every N frames (1 = every frame):"))
        perf_layout.addWidget(self.detect_n_spin)

        perf_hint = QLabel("Raise these values if video playback is too slow.")
        perf_hint.setStyleSheet("color: #888; font-size: 9pt;")
        perf_hint.setWordWrap(True)
        perf_layout.addWidget(perf_hint)

        perf_group.setLayout(perf_layout)
        layout.addWidget(perf_group)

        # Camera FOV
        fov_group = QGroupBox("Camera Field of View")
        fov_layout = QVBoxLayout()

        self.fov_x_input = QLineEdit("60")
        self.fov_y_input = QLineEdit("40")

        fov_layout.addWidget(QLabel("Horizontal FOV (degrees):"))
        fov_layout.addWidget(self.fov_x_input)
        fov_layout.addWidget(QLabel("Vertical FOV (degrees):"))
        fov_layout.addWidget(self.fov_y_input)

        fov_group.setLayout(fov_layout)
        layout.addWidget(fov_group)

        # Serial configuration
        serial_group = QGroupBox("Serial Output (HEX Format)")
        serial_layout = QVBoxLayout()

        self.serial_port_combo = QComboBox()
        self.refresh_serial_btn = QPushButton("Refresh Ports")
        self.refresh_serial_btn.clicked.connect(self.refresh_serial_ports)

        serial_layout.addWidget(QLabel("Serial Port:"))
        serial_layout.addWidget(self.serial_port_combo)
        serial_layout.addWidget(self.refresh_serial_btn)

        # توضیحات فرمت HEX
        hex_info = QLabel("Format: [AA55][Azimuth(4B)][Elevation(4B)][Checksum]")
        hex_info.setStyleSheet("color: #888; font-size: 9pt;")
        serial_layout.addWidget(hex_info)

        serial_group.setLayout(serial_layout)
        layout.addWidget(serial_group)

        # بارگذاری اولیه پورت‌ها
        self.refresh_serial_ports()

        # Control buttons

        # پیش‌نمایش زنده دوربین - بدون تشخیص/ردیابی
        stream_btn_layout = QHBoxLayout()
        self.start_stream_btn = QPushButton("Start Streaming")
        self.start_stream_btn.clicked.connect(self.start_streaming)
        self.stop_stream_btn = QPushButton("Stop Streaming")
        self.stop_stream_btn.setObjectName("dangerButton")
        self.stop_stream_btn.clicked.connect(self.stop_streaming)
        self.stop_stream_btn.setEnabled(False)
        stream_btn_layout.addWidget(self.start_stream_btn)
        stream_btn_layout.addWidget(self.stop_stream_btn)
        layout.addLayout(stream_btn_layout)

        # شروع/توقف تشخیص و ردیابی واقعی
        track_btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("Start Tracking")
        self.start_btn.clicked.connect(self.start_tracking)
        self.stop_btn = QPushButton("Stop Tracking")
        self.stop_btn.setObjectName("dangerButton")
        self.stop_btn.clicked.connect(self.stop_tracking)
        self.stop_btn.setEnabled(False)
        track_btn_layout.addWidget(self.start_btn)
        track_btn_layout.addWidget(self.stop_btn)
        layout.addLayout(track_btn_layout)

        layout.addStretch()

        return panel

    def create_display_panel(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # Video display
        video_group = QGroupBox("Video Output")
        video_layout = QVBoxLayout()
        self.video_label = QLabel()
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setMinimumSize(640, 480)
        self.video_label.setStyleSheet(f"border: 2px solid {BORDER};")
        video_layout.addWidget(self.video_label)
        video_group.setLayout(video_layout)
        layout.addWidget(video_group, 3)

        # Bottom section
        bottom_layout = QHBoxLayout()

        # Logo (bottom left)
        logo_label = QLabel()
        logo_pixmap = QPixmap("logo.png")
        if not logo_pixmap.isNull():
            scaled_logo = logo_pixmap.scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_label.setPixmap(scaled_logo)
        else:
            logo_label.setText("LOGO")
            logo_label.setStyleSheet(f"color: {BORDER}; font-size: 10pt;")
        logo_label.setAlignment(Qt.AlignBottom | Qt.AlignLeft)
        bottom_layout.addWidget(logo_label)

        # Angles display
        angles_group = QGroupBox("Target Angles")
        angles_layout = QVBoxLayout()

        self.azimuth_label = QLabel("Azimuth: 0.00°")
        self.azimuth_label.setStyleSheet(f"font-size: 16pt; color: {ACCENT};")
        self.elevation_label = QLabel("Elevation: 0.00°")
        self.elevation_label.setStyleSheet(f"font-size: 16pt; color: {ACCENT};")

        self.fps_label = QLabel("FPS: --")
        self.fps_label.setStyleSheet(f"font-size: 12pt; color: {ACCENT};")

        angles_layout.addWidget(self.azimuth_label)
        angles_layout.addWidget(self.elevation_label)
        angles_layout.addWidget(self.fps_label)
        angles_group.setLayout(angles_layout)
        bottom_layout.addWidget(angles_group, 1)

        # Radar display
        radar_group = QGroupBox("Radar Display")
        radar_layout = QVBoxLayout()
        self.radar_widget = RadarWidget()
        radar_layout.addWidget(self.radar_widget)
        radar_group.setLayout(radar_layout)
        bottom_layout.addWidget(radar_group, 1)

        layout.addLayout(bottom_layout, 1)

        return panel

    def toggle_source_type(self):
        """تغییر بین فایل و RTSP"""
        if self.file_radio.isChecked():
            self.video_path_input.setVisible(True)
            self.video_browse_btn.setVisible(True)
            self.rtsp_container.setVisible(False)
        else:
            self.video_path_input.setVisible(False)
            self.video_browse_btn.setVisible(False)
            self.rtsp_container.setVisible(True)

    def refresh_serial_ports(self):
        """به‌روزرسانی لیست پورت‌های سریال"""
        self.serial_port_combo.clear()
        ports = get_available_serial_ports()
        if ports:
            self.serial_port_combo.addItems(ports)
        else:
            self.serial_port_combo.addItem("No ports available")

    def browse_model(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select YOLO Model", "", "Model Files (*.pt *.onnx);;All Files (*)"
        )
        if file_path:
            self.model_path_input.setText(file_path)

    def browse_video(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Video File", "", "Video Files (*.mp4 *.avi *.mov);;All Files (*)"
        )
        if file_path:
            self.video_path_input.setText(file_path)

    def build_rtsp_url(self):
        """ساخت URL از IP و Port (تنها فیلدهای لازم برای اتصال RTSP)"""
        ip = self.rtsp_ip.text().strip()
        port = self.rtsp_port.text().strip()

        if not ip or not port:
            return None

        return f"rtsp://{ip}:{port}/"

    def get_video_source(self):
        """تعیین منبع ویدئو (فایل یا RTSP). در صورت خطا (None, error_message) برمی‌گرداند."""
        if self.file_radio.isChecked():
            video_source = self.video_path_input.text().strip()
            if not video_source:
                return None, "Please provide a video file path"
            return video_source, None
        else:
            video_source = self.build_rtsp_url()
            if not video_source:
                return None, "Please provide both the camera IP and Port"
            return video_source, None

    def start_streaming(self):
        """شروع پیش‌نمایش زنده دوربین بدون تشخیص/ردیابی"""
        video_source, error = self.get_video_source()
        if error:
            QMessageBox.warning(self, "Input Error", error)
            return

        # اگر ردیابی در حال اجراست، برای جلوگیری از تداخل با منبع ویدئو متوقفش می‌کنیم
        if self.detection_thread:
            self.stop_tracking()

        self.stream_thread = CameraStreamThread(video_source=video_source)
        self.stream_thread.frame_ready.connect(self.update_frame)
        self.stream_thread.error_signal.connect(self.show_error)
        self.stream_thread.fps_ready.connect(self.update_fps)
        self.stream_thread.start()

        self.start_stream_btn.setEnabled(False)
        self.stop_stream_btn.setEnabled(True)

    def stop_streaming(self):
        if self.stream_thread:
            self.stream_thread.stop()
            self.stream_thread = None

        self.start_stream_btn.setEnabled(True)
        self.stop_stream_btn.setEnabled(False)
        self.fps_label.setText("FPS: --")

    def start_tracking(self):
        model_path = self.model_path_input.text()

        # اگر پیش‌نمایش زنده در حال اجراست، برای جلوگیری از تداخل با منبع ویدئو متوقفش می‌کنیم
        if self.stream_thread:
            self.stop_streaming()

        # تعیین منبع ویدئو
        video_source, error = self.get_video_source()
        if error:
            QMessageBox.warning(self, "Input Error", error)
            return

        try:
            fov_x = float(self.fov_x_input.text())
            fov_y = float(self.fov_y_input.text())
        except ValueError:
            QMessageBox.warning(self, "Input Error", "Invalid FOV values")
            return

        if not model_path or not video_source:
            QMessageBox.warning(self, "Input Error", "Please provide model and video source")
            return

        # تنظیمات سریال (baud rate ثابت است و نیازی به انتخاب کاربر ندارد)
        serial_port = self.serial_port_combo.currentText()
        if serial_port == "No ports available" or not serial_port:
            serial_port = None
        baud_rate = DEFAULT_BAUD_RATE

        # تنظیمات کارایی (performance settings)
        device_map = {
            "Auto (recommended)": None,
            "CPU": "cpu",
            "GPU (CUDA)": "cuda:0",
        }
        device = device_map.get(self.device_combo.currentText())

        try:
            imgsz = int(self.imgsz_combo.currentText())
        except ValueError:
            imgsz = 640

        detect_every_n = self.detect_n_spin.value()

        # ارسال مقادیر fov به جای شیء CameraConfig
        self.detection_thread = DetectionThread(
            model_path=model_path,
            video_source=video_source,
            horizontal_fov=fov_x,  # ارسال مقدار float
            vertical_fov=fov_y,  # ارسال مقدار float
            serial_port=serial_port,  # رشته یا None
            baud_rate=baud_rate,
            device=device,
            imgsz=imgsz,
            detect_every_n_frames=detect_every_n,
        )
        self.detection_thread.frame_ready.connect(self.update_frame)
        self.detection_thread.angles_ready.connect(self.update_angles)
        self.detection_thread.error_signal.connect(self.show_error)
        self.detection_thread.fps_ready.connect(self.update_fps)
        self.detection_thread.start()

        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)

    def stop_tracking(self):
        if self.detection_thread:
            self.detection_thread.stop()
            self.detection_thread = None

        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.fps_label.setText("FPS: --")

    def update_frame(self, frame):
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_frame.shape
        bytes_per_line = ch * w
        qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image)
        scaled_pixmap = pixmap.scaled(self.video_label.size(), Qt.KeepAspectRatio)
        self.video_label.setPixmap(scaled_pixmap)

    def update_angles(self, azimuth, elevation):
        self.azimuth_label.setText(f"Azimuth: {azimuth:.2f}°")
        self.elevation_label.setText(f"Elevation: {elevation:.2f}°")
        self.radar_widget.set_angles(azimuth, elevation)

    def update_fps(self, fps):
        self.fps_label.setText(f"FPS: {fps:.1f}")

    def show_error(self, message):
        QMessageBox.critical(self, "Error", message)

    def closeEvent(self, event):
        if self.detection_thread:
            self.detection_thread.stop()
        if self.stream_thread:
            self.stream_thread.stop()
        event.accept()