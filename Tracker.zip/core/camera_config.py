import math


class CameraConfig:
    """تنظیمات دوربین و محاسبه زوایا"""

    def __init__(self, horizontal_fov=60.0, vertical_fov=45.0):
        """
        Args:
            horizontal_fov: زاویه دید افقی دوربین (درجه)
            vertical_fov: زاویه دید عمودی دوربین (درجه)
        """
        self.horizontal_fov = horizontal_fov
        self.vertical_fov = vertical_fov

    def calculate_angles(self, target_x, target_y, frame_width, frame_height):
        """
        محاسبه زوایای azimuth و elevation

        Args:
            target_x: موقعیت افقی مرکز هدف (پیکسل)
            target_y: موقعیت عمودی مرکز هدف (پیکسل)
            frame_width: عرض فریم (پیکسل)
            frame_height: ارتفاع فریم (پیکسل)

        Returns:
            (azimuth, elevation): زوایا به درجه
            azimuth: مثبت = راست، منفی = چپ
            elevation: مثبت = بالا، منفی = پایین
        """
        # محاسبه مرکز فریم
        center_x = frame_width / 2
        center_y = frame_height / 2

        # محاسبه فاصله از مرکز (نرمالایز شده)
        # مقدار بین -1 تا +1
        normalized_x = (target_x - center_x) / (frame_width / 2)
        normalized_y = (center_y - target_y) / (frame_height / 2)  # معکوس چون Y در تصویر از بالا به پایین است

        # محاسبه زاویه azimuth (افقی)
        # استفاده از تانژانت برای دقت بیشتر
        max_azimuth_rad = math.radians(self.horizontal_fov / 2)
        azimuth_rad = normalized_x * max_azimuth_rad
        azimuth = math.degrees(azimuth_rad)

        # محاسبه زاویه elevation (عمودی)
        max_elevation_rad = math.radians(self.vertical_fov / 2)
        elevation_rad = normalized_y * max_elevation_rad
        elevation = math.degrees(elevation_rad)

        return azimuth, elevation

    def set_fov(self, horizontal_fov, vertical_fov):
        """تنظیم زوایای دید دوربین"""
        self.horizontal_fov = horizontal_fov
        self.vertical_fov = vertical_fov
