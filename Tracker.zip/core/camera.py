import os
import time
import math

import cv2
import numpy as np
from PyQt5.QtCore import QThread, pyqtSignal


class CameraConfig:
    """تنظیمات دوربین و محاسبه زوایا"""

    def __init__(self, horizontal_fov=60.0, vertical_fov=45.0):
        """
        Args:
            horizontal_fov: زاویه دید افقی دوربین (درجه)
            vertical_fov: زاویه دید عمودی دوربین (درجه)
        """
        self.horizontal_fov = horizontal_fov
        self.vertical_fov = vertical_fov

    def calculate_angles(self, target_x, target_y, frame_width, frame_height):
        """
        محاسبه زوایای azimuth و elevation

        Args:
            target_x: موقعیت افقی مرکز هدف (پیکسل)
            target_y: موقعیت عمودی مرکز هدف (پیکسل)
            frame_width: عرض فریم (پیکسل)
            frame_height: ارتفاع فریم (پیکسل)

        Returns:
            (azimuth, elevation): زوایا به درجه
            azimuth: مثبت = راست، منفی = چپ
            elevation: مثبت = بالا، منفی = پایین
        """
        # محاسبه مرکز فریم
        center_x = frame_width / 2
        center_y = frame_height / 2

        # محاسبه فاصله از مرکز (نرمالایز شده)
        # مقدار بین -1 تا +1
        normalized_x = (target_x - center_x) / (frame_width / 2)
        normalized_y = (center_y - target_y) / (frame_height / 2)  # معکوس چون Y در تصویر از بالا به پایین است

        # محاسبه زاویه azimuth (افقی)
        # استفاده از تانژانت برای دقت بیشتر
        max_azimuth_rad = math.radians(self.horizontal_fov / 2)
        azimuth_rad = normalized_x * max_azimuth_rad
        azimuth = math.degrees(azimuth_rad)

        # محاسبه زاویه elevation (عمودی)
        max_elevation_rad = math.radians(self.vertical_fov / 2)
        elevation_rad = normalized_y * max_elevation_rad
        elevation = math.degrees(elevation_rad)

        return azimuth, elevation

    def set_fov(self, horizontal_fov, vertical_fov):
        """تنظیم زوایای دید دوربین"""
        self.horizontal_fov = horizontal_fov
        self.vertical_fov = vertical_fov


class CameraStreamThread(QThread):
    """
    فقط استریم زنده تصویر بدون تشخیص/ردیابی - برای پیش‌نمایش و اطمینان از
    اتصال صحیح دوربین/فایل قبل از شروع Tracking واقعی.
    """

    frame_ready = pyqtSignal(np.ndarray)
    error_signal = pyqtSignal(str)
    fps_ready = pyqtSignal(float)

    def __init__(self, video_source, display_width=800,
                 max_reconnect_attempts=5, reconnect_delay_sec=2.0):
        super().__init__()
        self.video_source = video_source
        self.display_width = display_width
        self.running = False

        # تنظیمات اتصال مجدد برای استریم RTSP
        self.max_reconnect_attempts = max_reconnect_attempts
        self.reconnect_delay_sec = reconnect_delay_sec

    def run(self):
        try:
            is_rtsp = isinstance(self.video_source, str) and self.video_source.startswith('rtsp')

            if is_rtsp:
                os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|stimeout;5000000'

            cap = cv2.VideoCapture(self.video_source)

            if not cap.isOpened():
                if is_rtsp:
                    self.error_signal.emit(
                        f"Cannot open camera stream at {self.video_source}.\n\n"
                        "Check that:\n"
                        "- the camera's IP is reachable from this PC (try 'ping <camera IP>')\n"
                        "- this PC's network adapter is on the same subnet as the camera\n"
                        "- the RTSP IP/port are correct"
                    )
                else:
                    self.error_signal.emit(f"Cannot open video source: {self.video_source}")
                return

            self.running = True

            frame_count = 0
            consecutive_failures = 0
            fps_smoothed = 0.0
            last_time = time.time()

            while self.running:
                ret, frame = cap.read()

                if not ret:
                    if is_rtsp:
                        consecutive_failures += 1
                        if consecutive_failures > self.max_reconnect_attempts:
                            self.error_signal.emit(
                                f"Lost connection to the camera at {self.video_source} after "
                                f"{self.max_reconnect_attempts} reconnect attempts.\n\n"
                                "Verify the camera and PC are on the same subnet and that "
                                "the camera is reachable, then try again."
                            )
                            break
                        cap.release()
                        self.msleep(int(self.reconnect_delay_sec * 1000))
                        cap = cv2.VideoCapture(self.video_source)
                        continue
                    else:
                        break

                consecutive_failures = 0
                frame_count += 1

                # خط‌های مرکز برای کمک به تراز کردن دوربین قبل از شروع ردیابی
                h, w = frame.shape[:2]
                cv2.line(frame, (w // 2, 0), (w // 2, h), (0, 255, 255), 1)
                cv2.line(frame, (0, h // 2), (w, h // 2), (0, 255, 255), 1)

                now = time.time()
                dt = now - last_time
                last_time = now
                if dt > 0:
                    instant_fps = 1.0 / dt
                    fps_smoothed = instant_fps if fps_smoothed == 0 else (0.9 * fps_smoothed + 0.1 * instant_fps)
                cv2.putText(frame, "STREAMING (no detection)", (10, h - 15),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (60, 170, 220), 2)
                if frame_count % 10 == 0:
                    self.fps_ready.emit(fps_smoothed)

                display_frame = self._resize_for_display(frame, self.display_width)
                self.frame_ready.emit(display_frame)

            cap.release()

        except Exception as e:
            self.error_signal.emit(f"Streaming error: {str(e)}")

    def _resize_for_display(self, frame, target_width):
        h, w = frame.shape[:2]
        if w > target_width:
            scale = target_width / w
            new_w = target_width
            new_h = int(h * scale)
            return cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        return frame

    def stop(self):
        self.running = False
        self.wait()
